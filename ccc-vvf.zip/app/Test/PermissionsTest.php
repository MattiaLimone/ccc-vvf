<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class PermissionsTest extends TestCase
{

    public function testUpdate()
    {

    }

    public function test__construct()
    {

    }

    public function testIndex()
    {

    }
}
