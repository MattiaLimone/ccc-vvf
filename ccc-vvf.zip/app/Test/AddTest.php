<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class AddTest extends TestCase
{

    public function testGetComuni()
    {

    }

    public function test__construct()
    {

    }

    public function testIndex()
    {

    }

    public function testNewEntry()
    {

    }
}
