<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class FormationTest extends TestCase
{

    public function testIndex()
    {

    }

    public function testAddSpecs()
    {

    }

    public function test__construct()
    {

    }

    public function testGetData()
    {

    }
}
