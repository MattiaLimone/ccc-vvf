<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class SearchTest extends TestCase
{

    public function testIndex()
    {

    }

    public function test__construct()
    {

    }

    public function testFilter()
    {

    }
}
