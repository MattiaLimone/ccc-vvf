<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class ImportTest extends TestCase
{

    public function testDo_upload()
    {

    }

    public function testCheckPreImport()
    {

    }

    public function test__construct()
    {

    }

    public function testIndex()
    {

    }

    public function testImport()
    {

    }
}
