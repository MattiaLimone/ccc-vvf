<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class UpdateTest extends TestCase
{

    public function testUpdate()
    {

    }

    public function test__construct()
    {

    }

    public function testGetComuni()
    {

    }

    public function testIndex()
    {

    }

    public function testGetData()
    {

    }
}
