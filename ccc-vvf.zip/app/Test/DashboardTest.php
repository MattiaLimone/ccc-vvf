<?php

namespace App\Controllers\Admin;

use PHPUnit\Framework\TestCase;

class DashboardTest extends TestCase
{

    public function testIndex()
    {

    }

    public function test__construct()
    {

    }
}
