<?php

namespace App\Controllers\Admin;

use PHPUnit\Framework\TestCase;

class LogoutTest extends TestCase
{

    public function testIndex()
    {

    }
}
