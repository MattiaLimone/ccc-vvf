<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class FonogrammaTest extends TestCase
{

    public function test__construct()
    {

    }

    public function testGetPdf()
    {

    }

    public function testIndex()
    {

    }

    public function testGetAll()
    {

    }

    public function testGetData()
    {

    }

    public function testNewEntry()
    {

    }
}
