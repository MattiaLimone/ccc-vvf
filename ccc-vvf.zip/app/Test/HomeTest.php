<?php

namespace App\Controllers\Admin;

use PHPUnit\Framework\TestCase;

class HomeTest extends TestCase
{

    public function testIndex()
    {

    }
}
