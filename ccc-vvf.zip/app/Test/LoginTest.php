<?php

namespace App\Controllers\Admin;

use PHPUnit\Framework\TestCase;

class LoginTest extends TestCase
{

    public function testIndex()
    {

    }

    public function testLogin()
    {

    }
}
