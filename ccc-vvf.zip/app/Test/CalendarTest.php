<?php

namespace App\Controllers\Admin\Dashboard;

use PHPUnit\Framework\TestCase;

class CalendarTest extends TestCase
{

    public function testGetData()
    {

    }

    public function testGetCalendarEvents()
    {

    }

    public function testGetTurni()
    {

    }

    public function test__construct()
    {

    }

    public function testIndex()
    {

    }
}
